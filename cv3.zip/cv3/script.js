

// const button=document.getElementsByTagName("button")[0];
// console.log("button: ",button)
// button.addEventListener("click",handleFetch);
// async function handleFetch(){
//     await fetch("https://ethgasstation.info/api/ethgasAPI.json?api-key=f6af3c6fa284aba97a5780d2d2f03ad0335342c80ab19583c1f6b5afc1f3",{method:"GET",headers:{"Content-Type":"application/json"}}).then((res)=>console.log("res: ",res));
// }